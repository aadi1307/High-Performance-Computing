%by starting the problem I visualise a flowchart which helps in better
%understanding of the problem

%FEM Code Structure Flowchart

%Start: Define Parameters (E, A, f_tilde, L, g1, h, num_nodes) ->

%Discretize Domain Into Nodes and Calculate dx ->

%Initialize Global Stiffness Matrix (K_global) and Force Vector (F_global)
%->

%Assemble Global Stiffness Matrix from Local Stiffness Matrices ->

%Apply Boundary Conditions to K_global and F_global ->

%Solve for Displacements (U) and Plot Results


% Define the mechanical properties and geometric dimensions of the system
% as this is given information
E = 1e11; % Modulus of elasticity in Pascal
A = 1e-4; % Area of cross-section in square meters
f_tilde = 1e6; % Uniformly distributed load in Newtons per meter
L = 0.1; % Total length of the bar in meters
g1 = 0; % Displacement boundary condition at the left end
h = 1e6; % Applied traction at the right end
num_nodes = 4; % Number of nodes used in the mesh

% Creating a mesh of the domain with uniform spacing (used gpt as the
% prompt was to create a mesh should it be uniformaly distributed and if
% yes whats the syntax
dx = L / (num_nodes - 1); % Calculating the spacing between nodes
nodes = linspace(0, L, num_nodes); % Generate list of node locations

% Construct the global stiffness matrix and force vector
K_global = zeros(num_nodes); % Initialize stiffness matrix to zero
F_global = f_tilde * ones(num_nodes, 1) * dx; % Initialize force vector with distributed load

% Defining the stiffness matrix for each and individual elements
K_local = (E * A / dx) * [1, -1; -1, 1]; % Element stiffness matrix for uniform bar elements

% Assemble the global stiffness matrix from local matrices
for i = 1:(num_nodes - 1)
    K_global(i:i+1, i:i+1) = K_global(i:i+1, i:i+1) + K_local; % Superposition of local matrices
end

% Incorporate the boundary conditions into the global system
% Set the displacement at the first node
K_global(1, :) = 0; % Zero out the first row for boundary condition
K_global(1, 1) = 1; % Set the diagonal to 1 for boundary condition
F_global(1) = g1; % Set the first value of the force vector for boundary condition

% Setting the force at the last node
F_global(end) = F_global(end) + h; % Add the boundary traction to the last node

% Computing the nodal displacements by solving the system of equations
U = K_global \ F_global; % Solve for displacements

% for the visulaization of the displacement along the bar
figure; % Create a new figure window
plot(nodes, U, 'b-o', 'LineWidth', 2); % Plot the FEM displacements as blue circles
xlabel('Position x (m)'); % Label the x-axis
ylabel('Displacement u (m)'); % Label the y-axis
title('FEM Solution u(x) with 3 elements'); % Title for the plot
grid on; % Add a grid for better visualization

% Define the analytical solution for comparison function call
exact_solution = @(x) (0.11*x - 0.05*x.^2); % Function for exact solution

% Add the analytical solution to the plot
%prompted gpt how to distinguish the lines 
hold on; % Hold the current plot
fplot(exact_solution, [0 L], 'r--'); % Plot the exact solution as a red dashed line
legend('FEM Solution', 'Exact Solution'); % Add a legend to distinguish between plots
hold off; % Release the plot hold
