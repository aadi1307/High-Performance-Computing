% Initial setup: Define the physical constants for the system
E = 1e11; % Young's modulus in pascals (Pa)
A = 1e-4; % Cross-sectional area in square meters (m^2)
L = 0.1; % Length of the domain in meters (m)
g1 = 0; % Boundary condition at the start of the domain (x=0)
g2 = 0.001; % Boundary condition at the end of the domain (x=L)

% Discretization setup: Define the mesh
numElements = 3; % Modify to 100 for a more refined mesh
numNodes = numElements + 1; % Total number of nodes
nodeCoords = linspace(0, L, numNodes); % Node coordinates evenly distributed
elementNodes = [1:numElements; 2:numElements+1]'; % Element connectivity

% Global system matrices: Initialization of stiffness matrix and force vector
K = zeros(numNodes, numNodes); % Global stiffness matrix
F = zeros(numNodes, 1); % Global force vector

% Assembly process: Loop over each element to construct global matrices
for element = 1:numElements
    % Calculate the length of the current finite element
    elemLength = nodeCoords(elementNodes(element, 2)) - nodeCoords(elementNodes(element, 1));
    
    % Formulate the element stiffness matrix for a 1D bar element
    k_elem = (A*E/elemLength) * [1, -1; -1, 1];
    
    % Assemble the element stiffness into the global stiffness matrix
    globalNodeIds = elementNodes(element,:);
    K(globalNodeIds, globalNodeIds) = K(globalNodeIds, globalNodeIds) + k_elem;
end

% Boundary conditions: Impose Dirichlet boundary conditions on the system
K(1,:) = 0; K(:,1) = 0; K(1,1) = 1; F(1) = g1; % BC at x=0
K(end,:) = 0; K(:,end) = 0; K(end,end) = 1; F(end) = g2; % BC at x=L

% Solve the linear system for nodal displacements
U = K \ F;

% Post-processing: Plotting the FEM solution
figure;
plot(nodeCoords, U, 'b-o', 'LineWidth', 2, 'MarkerSize', 6); % Plot the computed FEM displacements
hold on;

% Exact solution function derived from boundary conditions
exactSolution = @(x) (g2 - g1) / L * x + g1;

% Plot the exact solution for comparison
fplot(exactSolution, [0 L], 'r-', 'LineWidth', 2); % Plot the exact solution as a function of x

% Enhancing the plot with descriptive labels and title
xlabel('x (m)'); % Label for the x-axis
ylabel('u (m)'); % Label for the y-axis
legend('FEM Solution', 'Exact Solution'); % Legend to distinguish the curves
title('Comparison of FEM and Exact Solution'); % Title of the plot

% Save the figure to files in different formats
saveas(gcf, 'FEM_Solution.png'); % Save as a PNG image
saveas(gcf, 'FEM_Solution.pdf'); % Save as a PDF file

% Release the plot hold to allow for other plots
hold off;
