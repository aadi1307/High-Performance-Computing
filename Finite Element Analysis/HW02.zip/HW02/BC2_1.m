% Clear workspace and close figures
clear; close all;

% Define the problem parameters
E = 1e11; % Young's modulus in Pa
A = 1e-4; % Cross-sectional area in m^2
L = 0.1; % Length of the domain in m
f_tilde = 1e6; % Constant force in N/m
g1 = 0; % Displacement at x=0
g2 = 0.001; % Displacement at x=L
h = 1e6; % Boundary traction (AEu,x) at x=L

% Define the number of elements and nodes
numElements = 100; % Number of elements
numNodes = numElements + 1; % Number of nodes is number of elements plus 1
dx = L / numElements; % Length of each element

% Initialize global stiffness matrix and force vector
K = zeros(numNodes, numNodes); % Global stiffness matrix
F = zeros(numNodes, 1); % Global force vector

% Construct element stiffness matrices and force vectors
for e = 1:numElements
    nodeIndices = e:e+1;
    
    % Element stiffness matrix (2x2 for linear elements)
    ke = (A * E / dx) * [1 -1; -1 1];
    
    % Element force vector (constant force distribution)
    fe = (f_tilde * dx / 2) * [1; 1];
    
    % Add to global stiffness matrix and force vector
    K(nodeIndices, nodeIndices) = K(nodeIndices, nodeIndices) + ke;
    F(nodeIndices) = F(nodeIndices) + fe;
end

% Apply boundary conditions
K(1,:) = 0; K(:,1) = 0; K(1,1) = 1; F(1) = g1; % Displacement boundary condition at node 1

% Modify force vector for known displacement at node end
F(numNodes-1) = F(numNodes-1) - K(numNodes-1, numNodes) * g2;

K(numNodes,:) = 0; K(:,numNodes) = 0; K(numNodes,numNodes) = 1; F(numNodes) = h / A - K(numNodes-1, numNodes) * g2; % Traction boundary condition at node end

% Solve the system of equations for displacements
U = K \ F;

% Plotting the FEM solution
figure;
x = linspace(0, L, numNodes);
plot(x, U, 'b-o', 'LineWidth', 1.5);
hold on;

% Compute and plot the exact solution
x_fine = linspace(0, L, 1000);
u_exact = exactSolution(x_fine, A, E, L, g1, g2, f_tilde);
plot(x_fine, u_exact, 'r-', 'LineWidth', 1.2);

% Plot settings
title('FEM solution comparison with Exact Solution');
xlabel('x [m]');
ylabel('u [m]');
legend('FEM', 'Exact');
grid on;
hold off;

% Define the exact solution function
function u = exactSolution(x, A, E, L, g1, g2, f_tilde)
    % Coefficients for the quadratic solution based on boundary conditions
    C2 = g1;
    C1 = (g2 - C2 - (f_tilde * L^2) / (2 * E * A)) / L;
    
    % Exact solution u(x)
    u = (-f_tilde / (2 * E * A)) * x.^2 + C1 * x + C2;
end
