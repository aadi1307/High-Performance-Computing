#include <iostream>
#include <Eigen/Dense>
#include <vector>

using Eigen::MatrixXd;
using Eigen::VectorXd;
using std::vector;

// Function to calculate the exact solution at a given point x
//This function calculates the theoretical exact displacement at a point x along a bar. 
//The calculation is based on the material properties (Young's modulus E, cross-sectional area A), 
//bar length L, boundary conditions (g1 at x=0 and g2 at x=L), and a constant force coefficient f_bar. 
//This represents the analytical solution to the problem.
double u_exact(double x, double E, double A, double L, double g1, double g2, double f_bar) {
    return (-f_bar / (6 * E * A)) * x * x * x
           + ((g2 - g1) / L + (f_bar * L * L) / (6 * E * A)) * x
           + g1;
}

int main() {
    // Material properties and problem setup
    double E = 1e11; // Young's modulus in Pa
    double A = 1e-4; // Cross-sectional area in m^2
    double L = 0.1;  // Length in m
    double g1 = 0;   // Boundary condition at x=0
    double g2 = 0.001; // Boundary condition at x=L
    double f_bar = 1e7; // Constant force coefficient N/m^2

    // the number of elements into which the bar is divided for the FEM analysis is defined. 
    //Two stiffness matrices (K3 for a 3-element system and K100 for a 100-element system) and force vectors 
    //(F3 and F100) are initialized to zero. 
    //These will hold the global stiffness of the system and the forces applied to each nodeNumber of elements
    
    int num_elements_3 = 3;
    int num_elements_100 = 100;

    // Initialize stiffness matrices and force vectors
    MatrixXd K3 = MatrixXd::Zero(num_elements_3 + 1, num_elements_3 + 1);
    VectorXd F3 = VectorXd::Zero(num_elements_3 + 1);
    MatrixXd K100 = MatrixXd::Zero(num_elements_100 + 1, num_elements_100 + 1);
    VectorXd F100 = VectorXd::Zero(num_elements_100 + 1);

    // Define element length
    double element_length_3 = L / num_elements_3;
    double element_length_100 = L / num_elements_100;

    // Assembly process
    auto assemble = [&](int num_elements, double element_length, MatrixXd &K, VectorXd &F) {
        for (int i = 0; i < num_elements; ++i) {
            // Stiffness matrix for each element
            double k_local_value = E * A / element_length;
            MatrixXd k_local(2, 2);
            k_local << k_local_value, -k_local_value,
                       -k_local_value, k_local_value;

            // Add local stiffness to global stiffness matrix
            int index1 = i;
            int index2 = i + 1;
            K.block(index1, index1, 2, 2) += k_local;

            // Force vector for each element
            double f_local_value = element_length / 2 * f_bar * element_length * (2 * i + 1) / 2;
            VectorXd f_local(2);
            f_local << f_local_value, f_local_value;
            F.segment(index1, 2) += f_local;
        }
    };

    // Assemble systems
    assemble(num_elements_3, element_length_3, K3, F3);
    assemble(num_elements_100, element_length_100, K100, F100);

    // Apply boundary conditions
    auto applyBoundaryConditions = [](MatrixXd &K, VectorXd &F, double g1, double g2) {
        int size = K.cols();
        K.row(0) = VectorXd::Zero(size);
        K(0, 0) = 1;
        F(0) = g1;
        K.row(size - 1) = VectorXd::Zero(size);
        K(size - 1, size - 1) = 1;
        F(size - 1) = g2;
    };

    applyBoundaryConditions(K3, F3, g1, g2);
    applyBoundaryConditions(K100, F100, g1, g2);

    // Solve systems of equations
    VectorXd u3 = K3.lu().solve(F3);
    VectorXd u100 = K100.lu().solve(F100);

    // Print the FEM solutions for verification
    std::cout << "FEM Displacements for 3 elements:" << std::endl << u3 << std::endl;
    std::cout << "FEM Displacements for 100 elements:" << std::endl << u100 << std::endl;

    // Now print the exact solutions for comparison
    std::cout << "Exact displacements for 3 elements:" << std::endl;
    for(int i = 0; i <= num_elements_3; ++i) {
        double x = i * element_length_3;
        std::cout << "u(" << x << ") = " << u_exact(x, E, A, L, g1, g2, f_bar) << std::endl;
    }

    std::cout << "Exact displacements for 100 elements (first 5 shown):" << std::endl;
    for(int i = 0; i < 101; ++i) {
        double x = i * element_length_100;
        std::cout << "u(" << x << ") = " << u_exact(x, E, A, L, g1, g2, f_bar) << std::endl;
    }

    return 0;
}
